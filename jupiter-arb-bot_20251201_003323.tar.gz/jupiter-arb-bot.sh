#!/bin/bash
# Jupiter Arbitrage Bot - Standalone Launcher

if ! command -v node &> /dev/null; then
    echo "❌ Node.js is required. Install from https://nodejs.org/"
    exit 1
fi

NODE_VERSION=$(node -v | cut -d'v' -f2 | cut -d'.' -f1)
if [ "$NODE_VERSION" -lt 16 ]; then
    echo "❌ Node.js 16+ required. Current: $(node -v)"
    exit 1
fi

# Get script directory
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Check if bot exists
if [ ! -f "$SCRIPT_DIR/dist/bot.js" ]; then
    echo "❌ Error: dist/bot.js not found"
    echo "Please ensure you have the complete bot package"
    exit 1
fi

# Run the standalone bot (all dependencies bundled)
cd "$SCRIPT_DIR"
node dist/bot.js "$@"
